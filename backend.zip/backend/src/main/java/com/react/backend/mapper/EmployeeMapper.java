package com.react.backend.mapper;

import com.react.backend.dto.EmployeeDto;
import com.react.backend.entity.Employee;

public class EmployeeMapper {
	
	public static EmployeeDto mapToEmployeeDto(Employee employee)
	{
		return new EmployeeDto(
				employee.getId(),
				employee.getName(),
				employee.getEmail()
				);
	}
	
	public static Employee mapToEmployee(EmployeeDto employeeDto)
	{
		return new Employee(
				employeeDto.getId(),
				employeeDto.getName(),
				employeeDto.getEmail()
				);
	}

}
